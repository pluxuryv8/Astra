// Copyright (c) Microsoft Corporation. All rights reserved.
// CountMessage.cs

#region snippet_CountMessage
namespace GettingStartedSample;

public class CountMessage
{
    public int Content { get; set; }
}
#endregion
